<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name=$_POST['signupname'];
    $email = $_POST['signupEmail'];
    $password1 = $_POST['signupPassword'];

    // You should add server-side validation and sanitize input data here

    // Store the user information in a database (MySQL, for example)
    // Replace the database connection and query with your actual implementation

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "netfdb";

    $conn=mysqli_connect("localhost","root","","netfdb");

    if(!$conn) {
        die("Connection Failed".mysqli_connect_error());
    }
    
    // Insert data into the table
    $sql = "INSERT INTO users (name,email,password)
            VALUES ('$name','$email', '$password1')";
    
    
    if(mysqli_query($conn,$sql)) {
        echo '<script>alert("Record inserted succesfully.")</script>';
    }
   
}
?>
