<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST["signup-name"];
    $email = $_POST["signup-email"];
    $password = $_POST["signup-password"];

    // Create a string with user data
    $userData = "Name: $name\nEmail: $email\nPassword: $password\n\n";

    // Specify the path to the text file where user data will be saved
    $filePath = "user_data.txt";

    // Append user data to the text file
    if (file_put_contents($filePath, $userData, FILE_APPEND | LOCK_EX)) {
        echo "User data saved successfully!";
    } else {
        echo "Error saving user data.";
    }
}
?>
