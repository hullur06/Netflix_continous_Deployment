<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['loginEmail'];
    $password1 = $_POST['loginPassword'];



    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "netfdb";
    
    $conn=mysqli_connect("localhost","root","","netfdb");

    if(!$conn) {
        die("Connection Failed".mysqli_connect_error());
    }
        

        $sql = "SELECT * FROM users WHERE email='$email' AND password='$password1'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        $user = $stmt->fetch();

        if ($user) {
            $_SESSION['user_id'] = $user['email']; // Store user ID in session
            header("Location: index.html"); // Redirect to the next page
            exit();
        } else {
            echo "Invalid email and password.";
           
            header("Location: lo.html");

        }
       $conn = null;
}

